## Estou fazendo Friday Night Funkin Dad_Battle 1 fase com HTML e Python
Friday Night Funkin Dad_Battle 1 fase com HTML está em andamento.
Porém, se quiser jogar com python então:
## Por favor, antes de iniciar o jogo, instale pygame.

```
pip install pygame
```