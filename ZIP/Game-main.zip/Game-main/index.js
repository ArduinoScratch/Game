var img_up = document.getElementsByClassName(img_up);
var loop = true;
var y = -860;
    async function y(){
while (loop) {
    y = y + 2;
    if (y > -286) {
        y = await -1000;
    };
    console.log(y);
    }
}
